/*
 * led_display.h
 *
 *  Created on: Oct 1, 2025
 *      Author: TruongGiaHy_2352458
 */

#ifndef INC_LED_DISPLAY_H_
#define INC_LED_DISPLAY_H_

extern int led_buffer[6];
extern int seg_buffer[4];

void resetBuffer(void);
void updateLED(void);
void update7SEG(void);

void led_display_Init(void);
void fsm_for_led_display(void);

#endif /* INC_LED_DISPLAY_H_ */
