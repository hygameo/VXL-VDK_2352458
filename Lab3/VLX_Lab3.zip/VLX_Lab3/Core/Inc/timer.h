/*
 * timer.h
 *
 *  Created on: Oct 1, 2025
 *      Author: TruongGiaHy_2352458
 */

#ifndef INC_TIMER_H_
#define INC_TIMER_H_

#define MAX_SOFT_TIMER 3

extern int TIMER_CYCLE;
extern int timer_flag[MAX_SOFT_TIMER];

void setSoftTimer(int index, int duration);

#endif /* INC_TIMER_H_ */
