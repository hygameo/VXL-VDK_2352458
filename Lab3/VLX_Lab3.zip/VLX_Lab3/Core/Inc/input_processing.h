/*
 * input_processing.h
 *
 *  Created on: Oct 10, 2025
 *      Author: hygam
 */

#ifndef INC_INPUT_PROCESSING_H_
#define INC_INPUT_PROCESSING_H_

void fsm_for_input_processing(void);

#endif /* INC_INPUT_PROCESSING_H_ */
