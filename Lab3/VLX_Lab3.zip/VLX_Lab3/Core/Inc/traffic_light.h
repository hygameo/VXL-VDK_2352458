/*
 *  trafic_light.h
 *
 *  Created on: Oct 1, 2025
 *      Author: TruongGiaHy_2352458
 */

#ifndef INC_TRAFFIC_LIGHT_H_
#define INC_TRAFFIC_LIGHT_H_

extern int redSec;
extern int yellowSec;
extern int greenSec;

void traffic_Init(void);
void modifySec_Init(int whichsec);
void fsm_for_trafic_light(void);
void fsm_for_traffic_modifySec(int whichsec);

#endif /* INC_TRAFFIC_LIGHT_H_ */
