/*
 * input_reading.h
 *
 *  Created on: Oct 1, 2025
 *      Author: TruongGiaHy_2352458
 */

#ifndef INC_INPUT_READING_H_
#define INC_INPUT_READING_H_

void button_reading ( void );
unsigned char is_button_pressed ( unsigned int index );
unsigned char is_button_pressed_once(unsigned int index);
unsigned char is_button_pressed_1s ( unsigned int index );

#endif /* INC_INPUT_READING_H_ */
