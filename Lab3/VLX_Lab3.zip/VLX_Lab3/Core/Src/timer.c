/*
 * timer.c
 *
 *  Created on: Oct 1, 2025
 *      Author: TruongGiaHy_2352458
 */

#include "main.h"
#include "input_reading.h"

#define MAX_SOFT_TIMER 3

int TIMER_CYCLE = 10;

int timer_counter[MAX_SOFT_TIMER];
int timer_flag[MAX_SOFT_TIMER];

void setSoftTimer(int index, int duration) {
	if (index < MAX_SOFT_TIMER) {
		timer_counter[index] = duration / TIMER_CYCLE;
		timer_flag[index] = 0;
	}
}

void softTimer_run() {
	for (int i = 0; i < MAX_SOFT_TIMER; i++) {
		if (timer_counter[i] > 0) {
			timer_counter[i]--;
			if (timer_counter[i] == 0) timer_flag[i] = 1;
		}
	}
}

void HAL_TIM_PeriodElapsedCallback ( TIM_HandleTypeDef * htim )
{
	if(htim -> Instance == TIM2 ){
		softTimer_run();
		button_reading();
	}
}
