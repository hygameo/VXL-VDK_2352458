/*
 * led_display.c
 *
 *  Created on: Oct 1, 2025
 *      Author: TruongGiaHy_2352458
 */

#include "main.h"
#include "timer.h"

#define SEG_HIGH GPIO_PIN_RESET
#define SEG_LOW  GPIO_PIN_SET
#define LED_HIGH GPIO_PIN_SET
#define LED_LOW  GPIO_PIN_RESET

uint8_t segmentMap[11] = {
	0b0000001, 0b1001111,
	0b0010010, 0b0000110,
	0b1001100, 0b0100100,
	0b0100000, 0b0001111,
	0b0000000, 0b0000100,
	0b1111111
};

uint16_t ENPin[4] = {
	EN0_Pin, EN1_Pin,
	EN2_Pin, EN3_Pin
};

GPIO_TypeDef* ENPort[4] = {
	EN0_GPIO_Port, EN1_GPIO_Port,
	EN2_GPIO_Port, EN3_GPIO_Port
};

uint16_t LEDPin[6] = {
	LED0_Pin, LED1_Pin,
	LED2_Pin, LED3_Pin,
	LED4_Pin, LED5_Pin
};

GPIO_TypeDef* LEDPort[6] = {
	LED0_GPIO_Port, LED1_GPIO_Port,
	LED2_GPIO_Port, LED3_GPIO_Port,
	LED4_GPIO_Port, LED5_GPIO_Port
};

int led_buffer[6] = {0, 0, 0, 0, 0, 0};
int seg_buffer[4] = {0, 0, 0, 0};

void updateLED(){
	for(int i = 0; i < 6; i++) HAL_GPIO_WritePin(LEDPort[i], LEDPin[i], led_buffer[i] ? LED_HIGH : LED_LOW);
}

void update7SEG() {
    for (int i = 7; i >= 0; i--) {
        HAL_GPIO_WritePin(DATA0_GPIO_Port, DATA0_Pin, (segmentMap[seg_buffer[0]] >> i) & 1);
        HAL_GPIO_WritePin(DATA1_GPIO_Port, DATA1_Pin, (segmentMap[seg_buffer[1]] >> i) & 1);
        HAL_GPIO_WritePin(DATA2_GPIO_Port, DATA2_Pin, (segmentMap[seg_buffer[2]] >> i) & 1);
        HAL_GPIO_WritePin(DATA3_GPIO_Port, DATA3_Pin, (segmentMap[seg_buffer[3]] >> i) & 1);

        HAL_GPIO_WritePin(CLK_GPIO_Port, CLK_Pin, GPIO_PIN_SET);
        HAL_Delay(1);
        HAL_GPIO_WritePin(CLK_GPIO_Port, CLK_Pin, GPIO_PIN_RESET);
    }

    HAL_GPIO_WritePin(LATCH_GPIO_Port, LATCH_Pin, GPIO_PIN_SET);
    HAL_Delay(1);
    HAL_GPIO_WritePin(LATCH_GPIO_Port, LATCH_Pin, GPIO_PIN_RESET);
}

void resetBuffer(void){
	for(int i = 0; i < 6; i++) led_buffer[i] = 0;
	for(int i = 0; i < 4; i++) seg_buffer[i] = 0;
	updateLED();
	update7SEG();
}

void led_display_Init(){
	setSoftTimer(0, TIMER_CYCLE);
}

void fsm_for_led_display()
{
    if (timer_flag[0] == 1) {
        timer_flag[0] = 0;
        setSoftTimer(0, 100);

        updateLED();
        update7SEG();
    }
}
