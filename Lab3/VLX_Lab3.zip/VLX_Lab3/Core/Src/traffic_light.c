/*
 * trafic_light.c
 *
 *  Created on: Oct 1, 2025
 *      Author: TruongGiaHy_2352458
 */

#include "main.h"
#include "timer.h"
#include "led_display.h"

typedef enum {
    STATE_RED_GREEN = 0,
    STATE_RED_YELLOW = 1,
    STATE_GREEN_RED = 2,
	STATE_YELLOW_RED = 3
} TrafficState;

TrafficState trafficState;

int redSec = 5;
int yellowSec = 2;
int greenSec = 3;

int countdownSec = 0;
int countdownSec7Seg[2] = {0 ,0};

int blinkState = 0;
int tempSec = 0;
int lastPressState0 = 0;
int pressState0 = 0;
int lastPressState1 = 0;
int pressState1 = 0;

void trafficSetLED(){
	for (int i = 0; i < 6; i++) led_buffer[i] = 0;
	switch (trafficState) {
	    case STATE_RED_GREEN:
	    	led_buffer[0] = 1;
	    	led_buffer[5] = 1;
	        break;
	    case STATE_RED_YELLOW:
	    	led_buffer[0] = 1;
	    	led_buffer[4] = 1;
	        break;
	    case STATE_GREEN_RED:
	    	led_buffer[2] = 1;
	    	led_buffer[3] = 1;
	        break;
	    case STATE_YELLOW_RED:
	    	led_buffer[1] = 1;
	    	led_buffer[3] = 1;
	        break;
	}
}

void trafficSet7Seg(){
	int a = countdownSec7Seg[0];
	int b = countdownSec7Seg[1];

	if (a < 0) a = 0;
	if (a > 99) a = 99;
	seg_buffer[0] = (a / 10) % 10;
	seg_buffer[1] = a % 10;

	if (b < 0) b = 0;
	if (b > 99) b = 99;
	seg_buffer[2] = (b / 10) % 10;
	seg_buffer[3] = b % 10;
}

void trafficSecCompute(int redsec, int yellowsec, int greensec){
	if(redsec != 0){
		redSec = redsec;
		greenSec = redsec - yellowSec;
	}
	if(yellowsec != 0){
		yellowSec = yellowsec;
		greenSec = redSec - yellowsec;
	}
	if(greensec != 0){
		greenSec = greensec;
		redSec = greensec + yellowSec;
	}
}

void traffic_Init(){
	resetBuffer();
	trafficState = STATE_RED_GREEN;
	trafficSecCompute(0, 0, 0);
	countdownSec = greenSec;
	countdownSec7Seg[0] = redSec;
	countdownSec7Seg[1] = greenSec;
	setSoftTimer(1, TIMER_CYCLE);
}

void modifySec_Init(int whichsec){
	resetBuffer();
	setSoftTimer(2, TIMER_CYCLE);
	tempSec = whichsec == 0 ? redSec : (whichsec == 1 ? yellowSec : greenSec);
}

void fsm_for_trafic_light(){
	if (timer_flag[1]) {
		timer_flag[1] = 0;
		setSoftTimer(1, 1000);

		trafficSecCompute(0, 0, 0);
		countdownSec7Seg[0]--;
		countdownSec7Seg[1]--;

		if (countdownSec == 0) {
			switch (trafficState) {
				case STATE_RED_GREEN:
					trafficState = STATE_RED_YELLOW;
					countdownSec7Seg[1] = yellowSec - 1;
					countdownSec = yellowSec;
					break;
				case STATE_RED_YELLOW:
					trafficState = STATE_GREEN_RED;
					countdownSec7Seg[0] = greenSec - 1;
					countdownSec7Seg[1] = redSec - 1;
					countdownSec = greenSec;
					break;
				case STATE_GREEN_RED:
					trafficState = STATE_YELLOW_RED;
					countdownSec7Seg[0] = yellowSec - 1;
					countdownSec = yellowSec;
					break;
				case STATE_YELLOW_RED:
					trafficState = STATE_RED_GREEN;
					countdownSec7Seg[0] = redSec - 1;
					countdownSec7Seg[1] = greenSec - 1;
					countdownSec = greenSec;
					break;
			}
		}

		countdownSec--;
		if (countdownSec < 0) countdownSec = 0;

		trafficSetLED();
		trafficSet7Seg();
	}
}

void fsm_for_traffic_modifySec(int whichsec){
	if (timer_flag[2]) {
		timer_flag[2] = 0;
		setSoftTimer(2, 250);

		blinkState = !blinkState;
		for(int i = 0; i < 6; i++) led_buffer[i] = (i == whichsec || i == whichsec + 3) ? blinkState : 0;
	}

	seg_buffer[0] = 0;
	seg_buffer[1] = whichsec + 2;
	seg_buffer[2] = (tempSec / 10) % 10;
	seg_buffer[3] = tempSec % 10;

	if(is_button_pressed_once(1)) pressState0 = !pressState0;
	if (pressState0 != lastPressState0) {
		lastPressState0 = pressState0;

		tempSec++;
	}

	if(is_button_pressed_once(2)) pressState1 = !pressState1;
	if (pressState1 != lastPressState1) {
		lastPressState1 = pressState1;

		switch(whichsec) {
			 case 0: trafficSecCompute(tempSec, 0, 0); break;
			 case 1: trafficSecCompute(0, tempSec, 0); break;
			 case 2: trafficSecCompute(0, 0, tempSec); break;
		 }
		tempSec = whichsec == 0 ? redSec : (whichsec == 1 ? yellowSec : greenSec);
	}
}


